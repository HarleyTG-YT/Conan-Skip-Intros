import shutil
import os
import tkinter as tk
from tkinter import ttk, messagebox

class ConfigReplacementApp:
    def __init__(self, root):
        self.root = root
        self.root.title("Conan Exiles Configuration Replacement")
        self.app_dir = os.path.dirname(os.path.abspath(__file__))
        self.storage_dir = os.path.join(self.app_dir, 'Storage')
        self.destination_directory = r"C:\Program Files (x86)\Steam\steamapps\common\Conan Exiles\ConanSandbox\Config"  # Fixed destination directory
        self.create_widgets()

    def create_widgets(self):
        # Welcome message
        self.welcome_label = tk.Label(self.root, text="Welcome to the Conan Exiles Configuration Replacement Script!\n"
                                                     "This script allows you to easily manage the configuration files for Conan Exiles.", padx=20, pady=20)
        self.welcome_label.pack()

        self.continue_button = tk.Button(self.root, text="Continue", command=self.show_menu)
        self.continue_button.pack(pady=10)

    def show_menu(self):
        self.welcome_label.pack_forget()
        self.continue_button.pack_forget()

        self.menu_frame = tk.Frame(self.root)
        self.menu_frame.pack(padx=20, pady=20)

        self.menu_label = tk.Label(self.menu_frame, text="Select an option:")
        self.menu_label.pack()

        self.option1_button = tk.Button(self.menu_frame, text="Default (Revert Everything)", command=lambda: self.replace_file('1'))
        self.option1_button.pack(pady=5)

        self.option2_button = tk.Button(self.menu_frame, text="Without Everything (No Movies)", command=lambda: self.replace_file('2'))
        self.option2_button.pack(pady=5)

        self.option3_button = tk.Button(self.menu_frame, text="Without Movie (No Main Conan Movie)", command=lambda: self.replace_file('3'))
        self.option3_button.pack(pady=5)

        self.exit_button = tk.Button(self.menu_frame, text="Exit", command=self.root.quit)
        self.exit_button.pack(pady=10)

    def replace_file(self, option):
        source_paths = {
            '1': os.path.join(self.storage_dir, 'Default', 'DefaultGame.ini'),
            '2': os.path.join(self.storage_dir, 'Without Everything', 'DefaultGame.ini'),
            '3': os.path.join(self.storage_dir, 'Without Movie', 'DefaultGame.ini')
        }
        source_file = source_paths.get(option, '')
        if not source_file or not os.path.exists(source_file):
            messagebox.showerror("Error", f"Source file does not exist: {source_file}")
            return

        destination_file = os.path.join(self.destination_directory, "DefaultGame.ini")

        if not os.path.exists(self.destination_directory):
            messagebox.showerror("Error", f"Destination directory does not exist: {self.destination_directory}")
            return

        self.menu_frame.pack_forget()

        # Create progress bar frame
        self.progress_frame = tk.Frame(self.root)
        self.progress_frame.pack(padx=20, pady=20)

        self.progress_label = tk.Label(self.progress_frame, text="Replacing file, please wait...")
        self.progress_label.pack()

        self.progress_bar = ttk.Progressbar(self.progress_frame, orient="horizontal", length=300, mode="determinate")
        self.progress_bar.pack(pady=10)

        self.progress_bar["maximum"] = 100
        self.progress_bar["value"] = 0

        # Start progress bar update
        self.progress_step = 100 / 15  # 15 seconds
        self.progress_bar_update = 0
        self.file_copy_thread = self.root.after(1000, self.update_progress, source_file, destination_file, 0)

    def update_progress(self, source_file, destination_file, elapsed):
        if elapsed >= 15:
            self.finalize_replacement(source_file, destination_file)
            return
        
        self.progress_bar["value"] = self.progress_step * (elapsed + 1)
        self.root.after(1000, self.update_progress, source_file, destination_file, elapsed + 1)

    def finalize_replacement(self, source_file, destination_file):
        try:
            shutil.copy2(source_file, destination_file)
            messagebox.showinfo("Success", "File replacement completed.\nThank you for using this script! - Made By HARLEY-THE-GAMER (HarleyTG)")
        except Exception as e:
            messagebox.showerror("Error", f"Error: {e}")

        self.progress_frame.pack_forget()
        self.show_menu()

if __name__ == "__main__":
    root = tk.Tk()
    app = ConfigReplacementApp(root)
    root.mainloop()
